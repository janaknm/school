function y = normalFn(x)
    y = sqrt(2) * erfinv(2*x-1);
end