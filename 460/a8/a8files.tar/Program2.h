header Program2
 
  uses UserSystem

  functions
    main ()

endHeader
