header MyProgram
 
  uses UserSystem

  functions
    main ()

endHeader
