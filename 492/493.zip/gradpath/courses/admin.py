from django.contrib import admin
from courses.models import Course, Section

admin.site.register(Course)
admin.site.register(Section)
