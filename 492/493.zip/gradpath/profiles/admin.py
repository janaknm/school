from django.contrib import admin
from profiles.models import UserProfile

admin.site.register(UserProfile)
