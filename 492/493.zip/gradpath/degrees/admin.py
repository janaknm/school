from django.contrib import admin
from degrees.models import Degree, College

admin.site.register(College)
admin.site.register(Degree)
