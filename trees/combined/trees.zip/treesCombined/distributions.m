function fn = normalFn(x)
    return sqrt(2) * erfinv(2x-1);
end